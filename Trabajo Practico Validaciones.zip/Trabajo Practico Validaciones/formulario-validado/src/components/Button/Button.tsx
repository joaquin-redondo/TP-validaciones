import styles from './Button.module.css';

interface Props {
  disabled: boolean;
}

export default function Button({ disabled }: Props) {
  return (
    <button type="submit" disabled={disabled} className={disabled ? styles.disabled : styles.active}>
      Enviar
    </button>
  );
}

import styles from './Input.module.css';

interface Props {
  label: string;
  name: string;
  value: string;
  type?: string;
  handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
}

export default function Input({ label, name, value, type = 'text', handleChange, error }: Props) {
  return (
    <div className={styles.inputGroup}>
      <label htmlFor={name}>{label}</label>
      <input
        id={name}
        name={name}
        value={value}
        type={type}
        onChange={handleChange}
        className={error ? styles.errorInput : ''}
      />
      {error && <p className={styles.errorText}>{error}</p>}
    </div>
  );
}

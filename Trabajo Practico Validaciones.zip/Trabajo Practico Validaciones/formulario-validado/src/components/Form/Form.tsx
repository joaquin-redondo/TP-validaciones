import { useState } from 'react';
import { formSchema } from '../../schemas/formSchema';
import Input from '../Input/Input';
import Button from '../Button/Button';
import styles from './Form.module.css';
import Swal from 'sweetalert2';

interface FormValues {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export default function Form() {
  const [formValues, setFormValues] = useState<FormValues>({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState<Partial<FormValues>>({});

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    const updatedValues = { ...formValues, [name]: value };
    setFormValues(updatedValues);

    try {
      await formSchema.validateAt(name, updatedValues);
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name as keyof FormValues];
        return newErrors;
      });
    } catch (error: any) {
      setErrors((prev) => ({ ...prev, [name]: error.message }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await formSchema.validate(formValues, { abortEarly: false });
      Swal.fire('Formulario enviado correctamente', '', 'success');

      setFormValues({
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
      });
      setErrors({});
    } catch (error: any) {
      const newErrors: Partial<FormValues> = {};
      error.inner.forEach((err: any) => {
        newErrors[err.path as keyof FormValues] = err.message;
      });
      setErrors(newErrors);
    }
  };

  const hasErrors = Object.keys(errors).length > 0;

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <h2>Formulario</h2>
      <Input label="Nombre" name="name" value={formValues.name} handleChange={handleChange} error={errors.name} />
      <Input label="Correo" name="email" value={formValues.email} handleChange={handleChange} error={errors.email} />
      <Input label="Contraseña" name="password" type="password" value={formValues.password} handleChange={handleChange} error={errors.password} />
      <Input label="Repetir Contraseña" name="confirmPassword" type="password" value={formValues.confirmPassword} handleChange={handleChange} error={errors.confirmPassword} />
      <Button disabled={hasErrors || Object.values(formValues).some((val) => val === '')} />
    </form>
  );
}
